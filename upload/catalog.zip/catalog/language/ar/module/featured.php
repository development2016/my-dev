<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'منتجات مميزة';

// Text
/******** websiteskin.com *******/				
$_['text_sale']          = 'بيع';
/******** /websiteskin.com *******/				
$_['text_tax']      = 'السعر بدون الضريبة:';