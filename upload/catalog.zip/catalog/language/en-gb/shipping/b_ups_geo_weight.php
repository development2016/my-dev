<?php
// Text
$_['text_title']       = 'UPS (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/ups.png"/>';
$_['icon_shipping_2']  = '&nbsp;UPS (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/ups.png"/> &nbsp; UPS (Weight Based)';