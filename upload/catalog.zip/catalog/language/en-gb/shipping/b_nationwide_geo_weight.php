<?php
// Text
$_['text_title']       = 'Nationwide Express (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/nationwide.png"/>';
$_['icon_shipping_2']  = '&nbsp;Nationwide Express (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/nationwide.png"/> &nbsp; Nationwide Express (Weight Based)';