<?php
// Text
$_['text_title']       = 'Kangaroo Worldwide Express (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/kangaroo.png"/>';
$_['icon_shipping_2']  = '&nbsp;Kangaroo Worldwide Express (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/kangaroo.png"/> &nbsp; Kangaroo Worldwide Express (Weight Based)';