<?php
// Text
$_['text_title']       = 'GD Express (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/gdex.png"/>';
$_['icon_shipping_2']  = '&nbsp;GD Express (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/gdex.png"/> &nbsp; GD Express (Weight Based)';