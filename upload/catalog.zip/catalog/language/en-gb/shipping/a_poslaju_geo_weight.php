<?php
// Text
$_['text_title']       = 'PosLaju (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/poslaju.png"/>';
$_['icon_shipping_2']  = '&nbsp;PosLaju (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/poslaju.png"/> &nbsp; PosLaju (Weight Based)';