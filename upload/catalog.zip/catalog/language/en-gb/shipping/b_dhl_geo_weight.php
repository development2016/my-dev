<?php
// Text
$_['text_title']       = 'DHL Express (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/dhl.png"/>';
$_['icon_shipping_2']  = '&nbsp;DHL Express (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/dhl.png"/> &nbsp; DHL Express (Weight Based)';