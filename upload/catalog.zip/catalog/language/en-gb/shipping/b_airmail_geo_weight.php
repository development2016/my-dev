<?php
// Text
$_['text_title']       = 'Air Mail (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/airmail.png"/>';
$_['icon_shipping_2']  = '&nbsp;Air Mail (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/airmail.png"/> &nbsp; Air Mail (Weight Based)';