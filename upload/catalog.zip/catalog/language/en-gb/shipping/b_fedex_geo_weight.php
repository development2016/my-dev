<?php
// Text
$_['text_title']       = 'FedEx Express (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/fedex.png"/>';
$_['icon_shipping_2']  = '&nbsp;FedEx Express (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/fedex.png"/> &nbsp; FedEx Express (Weight Based)';