<?php
// Text
$_['text_title']       = 'Airpak Express (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/airpak.png"/>';
$_['icon_shipping_2']  = '&nbsp;Airpak Express (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/airpak.png"/> &nbsp; Airpak Express (Weight Based)';