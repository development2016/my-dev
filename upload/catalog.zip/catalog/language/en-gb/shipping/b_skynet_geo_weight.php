<?php
// Text
$_['text_title']       = 'Skynet Worldwide (Weight Based: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/skynet.png"/>';
$_['icon_shipping_2']  = '&nbsp;Skynet Worldwide (Weight Based)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/skynet.png"/> &nbsp; Skynet Worldwide (Weight Based)';