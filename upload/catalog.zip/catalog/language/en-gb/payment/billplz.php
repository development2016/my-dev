<?php
/**
 * Billplz OpenCart Plugin
 * 
 * @package Payment Gateway
 * @author Wanzul-Hosting.com <sales@wanzul-hosting.com>
 * @version 2.0
 */
 
// Text
$_['text_title'] = 'Billplz Malaysia Online Payment Gateway (Visa, MasterCard, Maybank2u, MEPS, FPX, etc )';
