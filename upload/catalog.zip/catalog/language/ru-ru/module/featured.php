<?php
// Heading
$_['heading_title'] = 'Рекомендуемые';

// Text
/******** /websiteskin.com *******/				
$_['text_sale']          = 'Скидка';
/******** /websiteskin.com *******/				
$_['text_tax']      = 'Без НДС:';

