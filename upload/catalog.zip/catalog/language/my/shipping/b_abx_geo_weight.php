<?php
// Text
$_['text_title']       = 'ABX Express (Berdasarkan Berat: ';
$_['text_weight']      = 'Berat:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/abx.png"/>';
$_['icon_shipping_2']  = '&nbsp;ABX Express (Berdasarkan Berat)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/abx.png"/> &nbsp; ABX Express (Berdasarkan Berat)';