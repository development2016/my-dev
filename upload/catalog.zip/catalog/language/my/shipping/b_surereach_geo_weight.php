<?php
// Text
$_['text_title']       = 'Sure-Reach Worldwide Express (Berdasarkan Berat: ';
$_['text_weight']      = 'Berat:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/surereach.png"/>';
$_['icon_shipping_2']  = '&nbsp;Sure-Reach Worldwide Express (Berdasarkan Berat)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/surereach.png"/> &nbsp; Sure-Reach Worldwide Express (Berdasarkan Berat)';