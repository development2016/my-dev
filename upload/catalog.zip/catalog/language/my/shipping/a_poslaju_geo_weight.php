<?php
// Text
$_['text_title']       = 'PosLaju (Berdasarkan Berat: ';
$_['text_weight']      = 'Berat:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/poslaju.png"/>';
$_['icon_shipping_2']  = '&nbsp;PosLaju (Berdasarkan Berat)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/poslaju.png"/> &nbsp; PosLaju (Berdasarkan Berat)';