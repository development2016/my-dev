<?php
// Text
$_['text_title']       = 'TA-Q-BIN (Berdasarkan Berat: ';
$_['text_weight']      = 'Berat:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/taqbin.png"/>';
$_['icon_shipping_2']  = '&nbsp;TA-Q-BIN (Berdasarkan Berat)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/taqbin.png"/> &nbsp; TA-Q-BIN (Berdasarkan Berat)';