<?php
// Text
$_['text_title']       = 'FedEx Express (Berdasarkan Berat: ';
$_['text_weight']      = 'Berat:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/fedex.png"/>';
$_['icon_shipping_2']  = '&nbsp;FedEx Express (Berdasarkan Berat)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/fedex.png"/> &nbsp; FedEx Express (Berdasarkan Berat)';