<?php
// Text
$_['text_title']       = 'EMS (Berdasarkan Berat: ';
$_['text_weight']      = 'Weight:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/ems.png"/>';
$_['icon_shipping_2']  = '&nbsp;EMS (Berdasarkan Berat)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/ems.png"/> &nbsp; EMS (Berdasarkan Berat)';