<?php
// Text
$_['text_title']       = 'Kangaroo Worldwide Express (Berdasarkan Berat: ';
$_['text_weight']      = 'Berat:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/kangaroo.png"/>';
$_['icon_shipping_2']  = '&nbsp;Kangaroo Worldwide Express (Berdasarkan Berat)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/kangaroo.png"/> &nbsp; Kangaroo Worldwide Express (Berdasarkan Berat)';