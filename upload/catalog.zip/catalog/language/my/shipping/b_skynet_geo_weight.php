<?php
// Text
$_['text_title']       = 'Skynet Worldwide (Berdasarkan Berat: ';
$_['text_weight']      = 'Berat:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/skynet.png"/>';
$_['icon_shipping_2']  = '&nbsp;Skynet Worldwide (Berdasarkan Berat)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/skynet.png"/> &nbsp; Skynet Worldwide (Berdasarkan Berat)';