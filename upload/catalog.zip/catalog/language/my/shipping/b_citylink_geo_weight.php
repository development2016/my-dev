<?php
// Text
$_['text_title']       = 'City-Link Express (Berdasarkan Berat: ';
$_['text_weight']      = 'Berat:'; 
$_['icon_shipping_1']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/city-link.png"/>';
$_['icon_shipping_2']  = '&nbsp;City-Link Express (Berdasarkan Berat)';
$_['icon_shipping_3']  = '&nbsp;<img style="vertical-align:middle" src="image/data/shipping/city-link.png"/> &nbsp; City-Link Express (Berdasarkan Berat)';