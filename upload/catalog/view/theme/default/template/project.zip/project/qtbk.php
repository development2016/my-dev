<?php echo $header; ?>
<div class="container">
  <ul class="breadcrumb">
    <?php foreach ($breadcrumbs as $breadcrumb) { ?>
    <li><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a></li>
    <?php } ?>
  </ul>
  <?php if ($success) { ?>
  <div class="alert alert-success"><i class="fa fa-check-circle"></i> <?php echo $success; ?></div>
  <?php } ?>
  <?php if ($error_warning) { ?>
  <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> <?php echo $error_warning; ?></div>
  <?php } ?>
  <div class="row"><?php echo $column_left; ?>
    <?php if ($column_left && $column_right) { ?>
    <?php $class = 'col-sm-6'; ?>
    <?php } elseif ($column_left || $column_right) { ?>
    <?php $class = 'col-sm-9'; ?>
    <?php } else { ?>
    <?php $class = 'col-sm-12'; ?>
    <?php } ?>
    <div id="content" class="<?php echo $class; ?>"><?php echo $content_top; ?>
    	<h1><?php echo $heading_title; ?></h1>
	      <table class="table table-bordered" >
	          <tr>
	            <td colspan="2">
	            	<h2><b><?php echo $config_name; ?></b></h2> 
	            	<?php echo $config_address; ?> 
	            	<br>
	            	<b>Tel : </b><?php echo $config_telephone; ?> 
	            	<b>Fax : </b><?php echo $config_fax; ?>
	            	<b>Email : </b><?php echo $config_email; ?>
	            </td>

	          </tr>
	          <tr>
	          	<td align="center">
	          		<h3><b><?php echo $qt_title; ?></b></h3>
	          	</td>
	          </tr>
	          <tr>
	          	<td>
	          		<table class="table table-borderless">
	          			<tr>
	          				<td>To : </td>
	          				<td>{ company buyer} 
	          					<br>
								<b>Attention To </b> : {example}
								<br>
								<b>Contact </b> : {example}
								<br>
								<b>Email </b> : {example}
 							</td>
 							<td align="right"><?php echo $qt_no; ?> : </td>
 							<td align="right"><b>{QT NO}</b></td>
	          			</tr>
	          			<tr>
	          				<td></td>
	          				<td></td>
	          				<td align="right"><?php echo $qt_date; ?> : </td>
	          				<td align="right"><?= date('d-M-Y'); ?></td>
	          			</tr>
	          			<tr>
	          				<td>Delivery Address : </td>
	          				<td>
	          					{ company buyer} 
	          					<br>
								{ company address} 
							</td>
	          				<td></td>
	          				<td></td>
	          			</tr>
	          		</table>
	          	</td>
	          </tr>
	          <tr>
	          		<td>
	          			<?php $u_price = 0; ?>
	          			<table class="table table-bordered">
	          				<thead>
	          					<tr>
	          						<th style="background-color: #dedede;"><?php echo $tb_no; ?></th>
	          						<th style="background-color: #dedede;"><?php echo $tb_item; ?></th>
	          						<th style="background-color: #dedede;"><?php echo $tb_freight; ?></th>
	          						<th style="background-color: #dedede;"><?php echo $tb_qty; ?></th>
	          						<th style="background-color: #dedede;"><?php echo $tb_uprice; ?></th>
	          						<th style="background-color: #dedede;"><?php echo $tb_amount; ?></th>
	          					</tr>
	          				</thead>
	          				<tbody>
	          					<tr>
	          						<td>1</td>
	          						<td></td>
	          						<td>{empty}</td>
					                <td class="text-left">

					                </td>
	          						<td>
	          							


	          						</td>
	          						<td><b></b></td>
	          					</tr>
	          				</tbody>
	          			</table>



	          		</td>
	          </tr>
	          <tr>
	          	<td>
	          		
	          		<table class="table table-borderless">
	          			<tr>
	          				<td><?php echo $tb_sub_total; ?> : </td>
	          				<td></td>
 							<td></td>
 							<td align="right"></td>
	          			</tr>
	          			<tr>
	          				<td><?php echo $tb_freight_charge; ?> : </td>
	          				<td></td>
 							<td></td>
 							<td align="right">{value}</td>
	          			</tr>
	          			<tr>
	          				<td><?php echo $tb_tax; ?> % : </td>
	          				<td></td>
 							<td></td>
 							<td align="right">{value}</td>
	          			</tr>
	          			<tr>
	          				<td><h3><b><?php echo $tb_total; ?></b> (<?php echo $tb_tax; ?> %)</h3></td>
	          				<td></td>
 							<td></td>
 							<td align="right"><h3><b></b></h3></td>
	          			</tr>


	          		</table>




	          	</td>
	          </tr>
	 

	      </table>
      <?php echo $content_bottom; ?>
      </div>
    <?php echo $column_right; ?>
    </div>
</div>
<?php echo $footer; ?>